import React from "react";
import "./Component1912.css";

function Component1912(props) {
  const { children } = props;

  return (
    <div className="component-191-2 border-1px-snuff">
      <div className="export-my-data nunito-normal-dolphin-18px">{children}</div>
    </div>
  );
}

export default Component1912;
