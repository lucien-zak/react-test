import React from "react";
import "./Component2051.css";

function Component2051(props) {
  const { children } = props;

  return (
    <div className="component-205-1">
      <div className="all-expenses nunito-normal-dolphin-18px">{children}</div>
    </div>
  );
}

export default Component2051;
