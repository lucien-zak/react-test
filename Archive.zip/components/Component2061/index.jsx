import React from "react";
import "./Component2061.css";

function Component2061(props) {
  const { children } = props;

  return (
    <div className="component-206-1">
      <div className="accounting-export nunito-normal-dolphin-18px">{children}</div>
    </div>
  );
}

export default Component2061;
