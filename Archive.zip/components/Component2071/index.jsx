import React from "react";
import "./Component2071.css";

function Component2071(props) {
  const { children } = props;

  return (
    <div className="component-207-1">
      <div className="chart-of-accounts nunito-normal-dolphin-18px">{children}</div>
    </div>
  );
}

export default Component2071;
