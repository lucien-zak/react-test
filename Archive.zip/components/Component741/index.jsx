import React from "react";
import "./Component741.css";

function Component741(props) {
  const { children } = props;

  return (
    <div className="component-74-1">
      <div className="all-invoices">{children}</div>
    </div>
  );
}

export default Component741;
