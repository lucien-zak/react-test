import React from "react";
import "./Group844.css";

function Group844(props) {
  const { className } = props;

  return (
    <div className={`group-844-1 ${className || ""}`}>
      <img className="path-671" src="/img/path-671-1@1x.png" />
    </div>
  );
}

export default Group844;
